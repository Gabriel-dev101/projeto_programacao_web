<?php
$conn = new mysqli("localhost", "root", "", "projetoweb", 3306);

if ($conn->connect_errno) {
    die("Erro ao conectar ao banco: " . $conn->connect_error);
}
?>
