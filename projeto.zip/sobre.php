<!DOCTYPE html>
<html lang="en">
<head>
     <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <title>Sobré nós</title>
</head>
<body>
     <div class="all">
        <?php include("principais/header.php"); ?>
    <div class="container">
             <div class="textContainer">
                <h1>Sobre Nós</h1>
                 
                <div class="logoContainer">
                    <img src="../images/ChatGPT Image 27 de mai. de 2025, 16_12_45.png" alt="" style="width: 300px;">
                </div>
                
                
                <p>
                

                    
                    A Based nasceu para ser mais do que uma marca de roupas masculinas — somos uma expressão de identidade, confiança e autenticidade. Nossa missão é vestir o homem moderno com peças que unem estilo, qualidade e versatilidade para qualquer ocasião.
                </p>
                <p>
                    Na Based, acreditamos que roupa é mais do que aparência — é postura. Por isso, criamos coleções completas que vão do básico ao urbano, do casual ao elegante. Tudo com foco em caimento, conforto e design.
                </p>

                <p>
                    Na Based, acreditamos que roupa é mais do que aparência — é postura. Por isso, criamos coleções completas que vão do básico ao urbano, do casual ao elegante. Tudo com foco em caimento, conforto e design.

                </p>

                <p>
                    Seja camisa, moletom, bermuda, jaqueta, tênis, regata, boné  — na Based você encontra tudo. Aqui você monta seu estilo completo, em um só lugar.
                </p>

                <p>
                    Somos movidos por inovação, simplicidade e autenticidade. Mais do que vender roupas, queremos inspirar homens a se vestirem com confiança e se sentirem preparados para encarar qualquer desafio — sempre com estilo.
                </p>
            </div>
        </div>
     </div>
</body>
</html>