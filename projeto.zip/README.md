# projeto_programacao_web
trabalho final da disciplina de programação web



A Based Clothing é um projeto de loja de roupas voltado para um público jovem e moderno, que valoriza autenticidade, estilo e atitude. A proposta da marca é oferecer peças versáteis, confortáveis e alinhadas às principais tendências da moda urbana e streetwear. A loja busca se destacar pela identidade forte, comunicação criativa e compromisso com a qualidade dos produtos.O projeto inclui uma loja online intuitiva e dinâmica, garantindo praticidade nas compras e ampliando o alcance da marca. A Based Clothing tem como missão expressar personalidade através da moda e inspirar confiança em cada cliente.

o projeto deverá contar com uma gestão de produtos e usuários,gesão de produtos,simulação de compra e um painel de administrador

integrantes:Gabriel Dantas, Francisco César, Arthur Costa, Matheus Caldas e Tobias Feitoza
