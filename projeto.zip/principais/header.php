
  <div class="headerContainer">
            <header>
                <div class="logo">
                  <h1>BASED</h1>
                </div>
                
                <ul>
              <li><a href="index.php">Início</a></li>
                <li><a href="sobre.php">Sobre</a></li>
                 <li><a href="produtos.php">Produtos</a></li>
                 <li><a href="contato.php">Fale conosco</a></li>


                </ul>

                <div class="iconLists">
                    <i class="fa-solid fa-bars"></i>
                </div>
                <div class="profile">
                    <i class="fa-regular fa-user"></i>
                </div>
               
            </header> 
            <div class="blur"></div>
            <div class="listsContainer">
                 <ul>
                    <li>Início</li>
                    <li>Sobre</li>
                    <li>Produtos</li>
                    <li>Contato</li>
                </ul>
            </div>
            <div class="profileContainer">
                    <ul>
                        <li>Registre-se</li>
                        <li>Login</li>
                    </ul>
                </div>
        </div>

           <script src="../script.js"></script>